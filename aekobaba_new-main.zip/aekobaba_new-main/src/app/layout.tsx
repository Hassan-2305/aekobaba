import type { Metadata } from "next";
import { Archivo, Geist_Mono } from "next/font/google";
import "./globals.css";
import { DEFAULT_THEME, THEME_INIT_SCRIPT } from "@/lib/theme";

import { SiteHeader } from "@/components/brand/site-header";
import { SiteFooter } from "@/components/brand/site-footer";

// Absolute base for Open Graph / Twitter image URLs. Order: the configured
// canonical URL, then Vercel's production domain, then this deployment's own
// URL — localhost only in local development, so a shared preview link never
// points crawlers at http://localhost:3000/og.png.
function siteUrl(): string {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (configured && !/localhost|127\.0\.0\.1/.test(configured)) return configured;
  const vercel = process.env.VERCEL_PROJECT_PRODUCTION_URL ?? process.env.VERCEL_URL;
  if (vercel) return `https://${vercel}`;
  return configured || "http://localhost:3000";
}

const SITE_URL = siteUrl();

// Archivo, variable on width + weight: expanded cuts carry the display voice,
// the normal width carries reading text — one family, two distinct roles.
const archivo = Archivo({
  variable: "--font-archivo",
  subsets: ["latin"],
  axes: ["wdth"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Aekobaba — Packaging Marketplace",
    template: "%s · Aekobaba",
  },
  description:
    "Find real, source-verified packaging suppliers and send one quote request to all of them.",
  icons: {
    icon: [
      { url: "/brand/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/brand/favicon-96.png", sizes: "96x96", type: "image/png" },
      { url: "/favicon.ico", sizes: "48x48" },
    ],
    apple: "/brand/apple-touch-icon.png",
  },
  openGraph: {
    type: "website",
    siteName: "Aekobaba",
    title: "Aekobaba — Packaging Marketplace",
    description:
      "Find real, source-verified packaging suppliers and send one quote request to all of them.",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "Aekobaba — source-verified packaging marketplace",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Aekobaba — Packaging Marketplace",
    description:
      "Find real, source-verified packaging suppliers and send one quote request to all of them.",
    images: ["/og.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // data-theme defaults to light; the inline script swaps in a saved choice
    // before paint, which is why hydration warnings are suppressed here.
    <html lang="en" data-theme={DEFAULT_THEME} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
      </head>
      <body className={`${archivo.variable} ${geistMono.variable} min-h-screen bg-paper text-ink antialiased`}>
        <div className="flex min-h-screen flex-col">
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <SiteFooter />
        </div>
      </body>
    </html>
  );
}
