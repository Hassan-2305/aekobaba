import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { PriceDisplay, PriceTagInline } from "./price-display";
import { ProductActions } from "./product-actions";
import { ProductCard } from "./product-card";
import { ProvenanceLine } from "./provenance-line";
import { ReviewScore } from "./review-score";
import { TierBadge } from "./tier-badge";
import { QuantityBreakTable } from "./quantity-break-table";
import { makeProduct } from "@/lib/catalog/test-fixtures";

// Rendered-DOM verification (spec C2/C6/C7): presentational components are
// server-rendered to markup and asserted on the HTML itself.

const render = (node: React.ReactElement): string => renderToStaticMarkup(node);

describe("PriceDisplay — the truth rule (C2)", () => {
  it("renders 'Ask the supplier' for a null price and NO numeric price anywhere", () => {
    const product = makeProduct({ basePrice: null, priceUnit: null });
    const html = render(createElement(PriceDisplay, { product, size: "lg" as const }));

    expect(html).toContain("Ask the supplier");
    expect(html).not.toContain("$");
    expect(html).not.toContain("0.");
    // No published-price structure either.
    expect(html).not.toContain('data-testid="published-price"');
    expect(html).toContain('data-testid="ask-supplier-price"');
  });

  it("renders price, basis, and the per-unit figure when published", () => {
    const product = makeProduct({ basePrice: 0.58, priceUnit: 0.47 });
    const html = render(createElement(PriceDisplay, { product }));

    expect(html).toContain('data-testid="published-price"');
    expect(html).toContain("$0.58");
    expect(html).toContain("per jar");
    expect(html).toContain("≈ $0.47 per unit");
  });

  it("labels non-exact price types honestly (FROM/CALCULATOR)", () => {
    const from = render(
      createElement(PriceDisplay, { product: makeProduct({ priceType: "FROM", basePrice: 0.39 }) }),
    );
    expect(from).toContain("From price");
    const calc = render(
      createElement(PriceDisplay, {
        product: makeProduct({ priceType: "CALCULATOR", basePrice: 0.31 }),
      }),
    );
    expect(calc).toContain("Calculator quote");
  });
});

describe("PriceTagInline", () => {
  it("collapses to 'Ask the supplier' without a published price", () => {
    const html = render(
      createElement(PriceTagInline, { product: makeProduct({ basePrice: null }) }),
    );
    expect(html).toContain("Ask the supplier");
    expect(html).not.toContain("$");
  });
});

describe("ProvenanceLine (C6)", () => {
  it("shows the capture date and links the exact source URL", () => {
    const html = render(
      createElement(ProvenanceLine, {
        sourceUrl: "https://www.containerandpackaging.com/item/AMBER12",
        sourceCapturedAt: "2026-09-18T00:00:00Z",
      }),
    );

    expect(html).toContain("Verified from");
    expect(html).toContain("18 Sep 2026");
    expect(html).toContain('href="https://www.containerandpackaging.com/item/AMBER12"');
  });
});

describe("ProductActions — get a quote / get a sample", () => {
  it("renders exactly the two asks and the request form", () => {
    const html = render(createElement(ProductActions, { product: makeProduct() }));
    expect(html).toContain('data-testid="get-quote"');
    expect(html).toContain('data-testid="get-sample"');
    expect(html).toContain('data-testid="inquiry-dialog"');
    expect(html).not.toContain("Add to Quote Basket");
    expect(html).not.toContain('data-testid="compare"');
  });

  it("the request form asks for contact details, needs, design status and a file", () => {
    const html = render(createElement(ProductActions, { product: makeProduct() }));
    for (const name of [
      "name",
      "email",
      "company",
      "website",
      "phone",
      "quantity",
      "packagingType",
      "format",
      "designStatus",
      "description",
      "design",
    ]) {
      expect(html).toContain(`name="${name}"`);
    }
    expect(html).toContain('type="file"');
  });
});

describe("TierBadge", () => {
  it("renders human tier names", () => {
    expect(render(createElement(TierBadge, { status: "RECOMMENDED" }))).toContain("Recommended");
    expect(render(createElement(TierBadge, { status: "LISTED" }))).toContain("Listed");
    expect(render(createElement(TierBadge, { status: "QUOTE_ONLY" }))).toContain("Quote only");
  });
});

describe("ReviewScore", () => {
  it("renders score, count, and platform", () => {
    const html = render(
      createElement(ReviewScore, {
        reviewScore: 4.5,
        reviewCount: 214,
        reviewPlatform: "Trustpilot",
      }),
    );
    expect(html).toContain("4.5");
    expect(html).toContain("(214)");
    expect(html).toContain("via Trustpilot");
  });

  it("says plainly when no reviews are published", () => {
    const html = render(
      createElement(ReviewScore, { reviewScore: null, reviewCount: 0, reviewPlatform: null }),
    );
    expect(html).toContain("No published supplier rating");
    expect(html).not.toContain("★");
  });
});

describe("ProductCard — image-led results card", () => {
  it("leads with the representative packshot, alt text labelled 'representative'", () => {
    const product = makeProduct();
    const html = render(createElement(ProductCard, { product }));

    expect(html).toContain("aspect-square");
    const alt = html.match(/alt="([^"]*)"/);
    expect(alt?.[1]).toContain("representative");
  });

  it("keeps every evidence element on the card (provenance regression guard)", () => {
    const product = makeProduct();
    const html = render(createElement(ProductCard, { product }));

    expect(html).toContain(product.title);
    expect(html).toContain('href="/suppliers/test-supplier"');
    expect(html).toContain('data-testid="tier-badge"');
    expect(html).toContain("$1.23");
    expect(html).toContain("Min order:");
    expect(html).toContain("500 units");
    expect(html).toContain("Lead time:");
    expect(html).toContain("14 days");
    expect(html).toContain("Material:");
    expect(html).toContain("4.5 (214)");
    expect(html).toContain("via Trustpilot");
    // Imagery must not evict evidence: the provenance line stays on the card.
    expect(html).toContain('data-testid="provenance-line"');
    expect(html).toContain("Verified from");
  });

  it("collapses the price to 'Ask the supplier' with no numerals on the card", () => {
    const html = render(createElement(ProductCard, { product: makeProduct({ basePrice: null }) }));
    expect(html).toContain("Ask the supplier");
    expect(html).not.toContain("$");
  });

  it("links the card to the product page from image and title", () => {
    const product = makeProduct();
    const html = render(createElement(ProductCard, { product }));
    expect(
      html.match(new RegExp(`href="/products/${product.id}"`, "g"))?.length,
    ).toBeGreaterThanOrEqual(2);
  });

  it("renders a neutral placeholder instead of an img when a product has no image", () => {
    const html = render(
      createElement(ProductCard, { product: makeProduct({ primaryImage: null }) }),
    );
    expect(html).not.toContain("<img");
    expect(html).toContain("No image available");
  });
});

describe("QuantityBreakTable", () => {
  it("renders the supplier's published tiers in order", () => {
    const html = render(
      createElement(QuantityBreakTable, {
        breaks: [
          { minQty: 1, maxQty: 249, unitPrice: 0.58 },
          { minQty: 1000, maxQty: null, unitPrice: 0.39 },
        ],
      }),
    );
    expect(html).toContain('data-testid="quantity-breaks"');
    expect(html).toContain("1–249");
    expect(html).toContain("$0.58");
    expect(html).toContain("1,000+");
    expect(html).toContain("$0.39");
  });

  it("renders nothing when no breaks are published", () => {
    expect(render(createElement(QuantityBreakTable, { breaks: [] }))).toBe("");
  });
});

describe("Berlin demo review fixes", () => {
  it("flags captures older than two weeks", () => {
    const now = new Date("2026-10-06T00:00:00Z");
    const fresh = render(
      createElement(ProvenanceLine, { sourceUrl: "https://x.example", sourceCapturedAt: "2026-10-03T00:00:00Z", now }),
    );
    const old = render(
      createElement(ProvenanceLine, { sourceUrl: "https://x.example", sourceCapturedAt: "2026-09-21T00:00:00Z", now }),
    );
    expect(fresh).not.toContain('data-testid="stale-capture"');
    expect(old).toContain('data-testid="stale-capture"');
    expect(old.replace(/<!-- -->/g, "")).toContain("15 days old");
  });

  it("hides unpublished MOQ / lead time cells behind one muted line", () => {
    const html = render(
      createElement(ProductCard, { product: makeProduct({ moq: null, leadTimeDays: null }) }),
    ).replace(/<!-- -->/g, "");
    expect(html).not.toContain("Min order:");
    expect(html).not.toContain("Lead time:");
    expect(html).toContain("MOQ and lead time not published");
    expect(html).not.toContain("Ask the supplier");
  });

  it("labels the rating as a supplier rating", () => {
    const html = render(
      createElement(ReviewScore, { reviewScore: 4.4, reviewCount: 4779, reviewPlatform: "Trustpilot" }),
    );
    expect(html).toContain("Supplier rating");
    expect(html).toContain("4,779");
  });

  it("shows a pack price as a comparable per-unit price, in the published currency", () => {
    const product = {
      ...makeProduct({ basePrice: 73.72 }),
      priceBasis: "per 1000 bags, ex. VAT (GBP; £88.47 inc. VAT)",
    };
    const html = render(createElement(PriceTagInline, { product }));
    expect(html).toContain("£0.074");
    expect(html).toContain("/ bag");
    expect(html).toContain("£73.72");
    expect(html).toContain("GBP");
    expect(html).not.toContain("$");
  });
});

describe("Partner program labels", () => {
  it("labels the image source on every card", () => {
    const representative = render(createElement(ProductCard, { product: makeProduct({}) }));
    expect(representative).toContain("Representative image");
    const photo = render(
      createElement(ProductCard, {
        product: makeProduct({ primaryImage: { url: "/partners/berlin-packaging/33512.webp", alt: "Bottle" } }),
      }),
    );
    expect(photo).toContain("Supplier photo");
  });

  it("labels partner-supplied values instead of passing them off as captured", () => {
    const product = {
      ...makeProduct({ moq: 240, leadTimeDays: 5 }),
      partnerFacts: {
        supplierName: "Berlin Packaging",
        suppliedAt: "2026-10-10T00:00:00Z",
        moq: true,
        leadTime: true,
        casePack: 240,
      },
    };
    const html = render(createElement(ProductCard, { product })).replace(/<!-- -->/g, "");
    expect(html).toContain("MOQ, lead time, case of 240 supplied by Berlin Packaging, 10 Oct 2026");
  });
});

describe("Partner ribbon", () => {
  it("marks partner cards with the orange ribbon and nothing else", () => {
    const base = makeProduct();
    const partner = { ...base, supplier: { ...base.supplier, isPartner: true } };
    const html = render(createElement(ProductCard, { product: partner }));
    expect(html).toContain('data-testid="partner-ribbon"');
    expect(html).toContain("Aekobaba Partner");
    expect(html).toContain('data-partner="true"');
    expect(render(createElement(ProductCard, { product: base }))).not.toContain("partner-ribbon");
  });
});
